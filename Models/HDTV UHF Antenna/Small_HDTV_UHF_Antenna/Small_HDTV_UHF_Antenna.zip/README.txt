                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1729860
Small HDTV UHF Antenna by jeplans is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

A pretty darn good UHF TV Antenna

Wires are stripped 10 gage copper.  V is about 30 degrees.
-V (bowtie) wires are around 14 1/4" 
-Horizontal Wires of back(Reflector) about 16"
-Vertical Wire in middle of Reflector 5 1/8"
-Vertical Conductors on ends of Reflector are Aluminum foil strips sandwiched between end supports

23 Screws #6-32 x 3/8" Stainless Machine Screws.
Designed to sit on 1/2" dowel 

Be sure to visit http://jeplans.com

If like what you see, and want to help encourage me to continue sharing free 3D printing designs be sure to Tip Me.
Thanks,
James

# Print Settings

Printer: Flashforge CreatorPro
Rafts: No
Supports: Yes
Resolution: Medium
Infill: 25% should do.

Notes: 
Only the Center Back part needs supports. (uhf_antenna_1_-_center_back.stl)

Wires are stripped 10 gage copper.  V is about 30 degrees.
-V (bowtie) wires are around 14 1/4" 
-Horizontal Wires of back(Reflector) about 16"
-Vertical Wire in middle of Reflector 5 1/8"
-Vertical Conductors on ends of Reflector are Aluminum foil strips sandwiched between end supports

23 Screws #6-32 x 3/8" Stainless Machine Screws.
Designed to sit on 1/2" dowel