                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:1997048
Stackable Storage Box by Verris is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

**Update May 18th**: Printed a regular size thin box and noticed a gap on the top left rail that holds a stacked box. Causes the rail to not print. I've added v1.4 for that box to fix the issue.

-

**Update May 5**: Fixed another issue with the back ramp inside on the thin boxes.

-

**Update May 1**: Fixed another spacing issue in the two thin walled versions. They work much faster. The tall version took me 4.5 hours to print down from 8.5 I believe. There was a slight bow to the side walls on my tall one, but there are no problems stacking them or stacking on them.

-

**Update 2 Apr 30**: Added a v1.1 of the thin walled versions. Previous version had a .6mm gap between the bottom of the interior ramps along the corners and the floor.

-

**Update Apr 30**: I've added a tall version of the box which is the exact same except 20mm taller. This makes it easier to get things out of the box when another is stacked on top.

I've also added two versions of each with 1.4mm walls rather than 2mm walls. **I haven't finished printing one of these yet, I am currently doing so**. For my .4mm nozzle this takes the number of passes per layer from 5 down to 3. This should greatly reduce the print time. The dimensions are the same and should stack the same with any old boxes. The only exception is the old divider may not work with the new boxes.

-

**Update Dec 26**: Added a base that will clip together to hold multiple boxes in alignment next to each other in a nice line. Print a left and a right and add as many center pieces as you need.

-


I started running out of space for all of the parts I've been collecting in my drawers so I started looking around to buy a nice rack with removable bins to set on top of the full drawers to fill with even more things. After finding that reasonably priced ones got a lot of terrible reviews for being brittle or not stacking properly and anything quality was more expensive than I was willing to spend on it, I thought, why not just make some of my own and put my idle printer to use.

These storage boxes stack vertically and have slots to hold a vertical divider splitting them into two smaller compartments. At 100% they are 15cm deep with an extra 2cm lip on the front, 90cm wide and 7cm tall. They easily prints with no support and I've been printing them at draft quality. 

On an official i3 MK1 with 0.25mm draft settings they take around 6 hours and 20 minutes.



# Print Settings

Printer: Original Prusa i3 MK2
Rafts: Doesn't Matter
Supports: No
Resolution: 0.35
Infill: 20%