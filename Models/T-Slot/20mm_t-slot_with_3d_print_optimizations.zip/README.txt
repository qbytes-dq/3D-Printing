                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2331488
20mm t-slot with 3d print optimizations by econopotamus is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a 20mm t-slot beam where I have optimized several corners to keep the 3d prints from bulging. If you look at the measurements in the CAD diagram you will see some little "mouse bites" that I made concave in places a 3d printer can generate excess plastic.

I matched the groove width, center opening, and curve width to official drawings of the:
80/20 Inc., 20-2020, 20 Series, 20mm x 20mm T-Slotted Extrusion

This provides maximum compatibility with parts you can order online and lets you order aluminum in bulk if your prototyping works out. At least that's my plan :)

# Print Settings

Printer Brand: MakerGear
Printer: MakerGear M2
Rafts: Doesn't Matter
Supports: No
Resolution: 0.25mm layers
Infill: Doesn't matter

Notes: 
Since these are tall and thin, use a raft if you don't have really great platform adhesion. I started without rafts but every now and then got a detachment so now I use rafts and just run the bottom over a file for 30 seconds after printing.