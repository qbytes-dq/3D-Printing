                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:624625
3 Jaw Lathe Chuck by bobwomble is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

****UPDATE****
Durwin Pye has sorted out the Scad file so it is now brilliant, Thanks,
I have added it to the list of files -not for the faint of heart-

After printing some other designs and finding they did not work for me, I decided to have a go myself, So here it is, Please beware, I have made allowances for my own printer so I take no resonsibility if it doesnt work for you.  
Also, to state the obvious, this is a plastic chuck, it has its limits!.  
101mm diameter, 59mm thick plus 25mm jaw height.  
With thanks to;  
-Parametric Involute Bevel and Spur Gears by GregFrost  
http://www.thingiverse.com/thing:3575  
-Customizable Spiral Generator by walter  
http://www.thingiverse.com/thing:58406  
for the hard work  
****UPDATE****  
I have printed and tested (sort of) different jaw materials  And added photos  
ABS,......................Best grip  
Flexi at 85% infill ..2nd -being flexible they grab well   
PLA ......................3rd, ok but tend to over tighten, which could break the scroll  
NYLON..................3rd equal  

Thanks to MrArrow1961 for the reverse jaws thingiverse.com/thing:624814  

Check out this awesome assembly video https://vimeo.com/137431844   
by yuri9999!  http://www.thingiverse.com/make:155862  

I have not included the Scad file at the moment, as it is a real mess,  
if I can tidy it up I will post at a latter date-DONE
Thanks to Durwin Pye for cleaning the scad.

# Instructions

I have added photos for reference,  
Print,  
 1 face housing  
 1 rear housing, either bolt hole which is more stable, or 10mm hex  
 1 scroll  
 1 gear ring  
 3 drive gear  
 1 of each jaw 1, 2 and3  
the jaws are numbered as they have to be inserted in the correct order to get them to align.  
You will need 1 M8 hex key for the drive gears, mine is a very snug fit.  

I printed at 0.25mm layer height, 35% honeycomb infill  
 and sliced with slic3r 1.1.7, using a 0.4mm nozzle.  
Please check the resulting code for possible problems before you print, especially perimeters around holes   

7x M3 by 8mm long screws, (I cut down longer ones)  
 they are to attach the scroll to the gear ring, do not over tighten,   or you will strip out the plastic   
3x M4 by about 40mm long screws, these hold the drive gears in place, I had to file the head down on my ones so they would fit.  
6x M4 by about 20/30mm screws to hold the back plate on  
1x M10 bolt and nut for the drive shaft  

You will also need small files and sandpaper to touch up any lumps and bumps from printing, also maybe to smooth the gear ring inner and outer surface etc.  
Please be aware, I found the print supports for the face housing tricky  to remove, be patient and use a file to clean up if needed to get the jaws in  
Also drill bits to clear the holes  
** Test fit the jaws in the face housing before inserting anything else as these will most likely need a little filing, they should fit in and slide freely but not sloppy.  
Once everything is cleaned up and fits freely, screw the scroll and gear ring together not tight, and drop in to the housing, fit the 3 drive gears and screw in the M4 locking screws  
take your M8 hex key and make sure the gears turn easy then advance the scroll until you see the start of the thread, back it up a bit and insert  Jaw1, advance the scroll it should start pulling the jaw in then insert  jaw 2, then 3, screw on the back plate and your good to go.  
Good luck.