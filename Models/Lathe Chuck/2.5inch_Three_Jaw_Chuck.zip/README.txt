                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2670620
2.5inch Three Jaw Chuck by mdkendall is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

A 2.5inch (63mm) diameter three-jaw chuck.

The three self-centering jaws are reversible to allow holding larger work pieces. To fit them in the normal orientation, as shown in the photos, insert them in to the slots in the order A-B-C. To fit them reversed, insert them in the order C-B-A.

The mounting hole suits a spindle with an M14 x 1mm thread. This is the standard size used on the Unimat 3 machines and also the many recent "8-in-1 Mini Lathe" kits available from China.

All parts are fully printable in the orientation shown with no support material. The overhangs near the center of the housing have carefully constructed chamfers to ensure that, while there is bridging, there are no overhangs that would need support.

I suggest using a small brim when printing the jaws to ensure that there is no lifting around the teeth. A 2mm brim worked fine for me. The other parts can be printed as-is.

The 4mm holes around the edge of the housing and the scroll plate are for inserting tommy bars for tightening.

After printing clean up the parts and test their fit. If there are any tight spots in the fit of the jaws in the slots, or the jaw teeth in the scroll plate, clean up with a needle file as necessary. There is 0.2mm clearance in the model for all parts that must fit together so there should not be any problem.

Fit the scroll plate to the housing and clip the circlip over the shaft to secure it. Turn the scroll plate so the leading tip of scroll is just about to appear in one of the slots. Feed in jaw A, large end first, and turn the scroll plate to capture it. Repeat with jaw B in the next slot, then jaw C in the next.

If you want the CAD files for the purpose of making changes for remixes please use the following link. This is a Fusion 360 public link, from which you can view the model online and also download it in a variety of formats, including native Fusion 360 archive, IGIS and STEP.

https://a360.co/2QDeCV9