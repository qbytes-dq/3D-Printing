                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:3082592
Vice mechanical v2.0 - Single Material by BadSquishy is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Made all at once from one material.  This Thing is just all of the pieces of the "Vice mechanical v2.0" in a single file.  Available in AMF and STL formats.  

Color change is not intentional, ran out of orange PLA in the middle of the print.  

Used QTY 8ea, #8 x 1" flat head sheet metal screws.

# Print Settings

Printer Brand: Prusa
Printer: i3 MK3
Rafts: No
Supports: No
Resolution: 0.15mm
Infill: 20%
Filament_brand: Monoprice
Filament_color: Orange, Gray
Filament_material: PLA Plus+

Notes: 
Used Slic3r Prusa Edition 1.40.1
 - "0.15mm OPTIMAL MK3" print setting
 - "Generic PLA" filament settings
 - "Original Prusa i3 MK3" printer settings.  

0.4mm Nozzle
0.15mm layer height
215°C nozzle temp
60°C bed temp

44 hours 45 minutes print time.