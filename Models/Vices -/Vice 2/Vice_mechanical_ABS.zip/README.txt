                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2273175
Vice mechanical (ABS) by 3D-MPL is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

TECHNICAL CHARACTERISTICS OF THE TYPES:
* Overall dimensions: 220х120х70 mm;
* Total construction weight: 0.308 kg;
* Working stroke: 116 mm;
* The size of the sponge: 100x50 mm;
* Estimated compressive force (max): 200N (20 kG);
* Diameter of the threaded spindle (thrust thread): 20 mm

MY WALLETS FOR DONATS:

DONATIONALERTS: https://www.donationalerts.com/r/3dmpl
WebMoney: Z147898355795
BTC: 3EfgGiCuog6ryTy7rocCdMFSHxRLVa9a2p
ETH: 0x120a0C53e75F97B4e5E0845c267F54Da33a9edCE

# Print Settings

Printer Brand: FlashForge
Printer: Dreamer
Rafts: No
Supports: No
Resolution: 0.4
Infill: 15

Notes: 
Skeleton (platform): layer height: 0.4 mm; infill: 15%
Other details: layer height: 0,25 mm; infill: 25%

# Post-Printing

<iframe src="//www.youtube.com/embed/OVjpTjegKUo" frameborder="0" allowfullscreen></iframe>